--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "BASE";
--
-- Name: BASE; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "BASE" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251' LC_CTYPE = 'Russian_Russia.1251';


ALTER DATABASE "BASE" OWNER TO postgres;

\connect "BASE"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Диета; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Диета" (
    "Номер_диеты" integer NOT NULL,
    "Содержание_диеты" character(20) NOT NULL
);


ALTER TABLE public."Диета" OWNER TO postgres;

--
-- Name: Клетка; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Клетка" (
    "Id_Клетки" integer NOT NULL,
    "Номер_цеха" integer NOT NULL,
    "Наличие курицы в клетке" boolean NOT NULL
);


ALTER TABLE public."Клетка" OWNER TO postgres;

--
-- Name: Кормление куриц; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Кормление куриц" (
    "Номер_Кормления" integer NOT NULL,
    "Id_Работника" integer NOT NULL,
    "Id_курицы" integer NOT NULL,
    "Номер_диеты" integer NOT NULL,
    "Id_клетки" integer NOT NULL,
    "Id_породы" integer NOT NULL,
    "Время_кормления" time(4) with time zone NOT NULL,
    "Дата_кормления" date
);


ALTER TABLE public."Кормление куриц" OWNER TO postgres;

--
-- Name: Курица; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Курица" (
    "Id_курица" integer NOT NULL,
    "id_клетки" integer NOT NULL,
    "Id_породы" integer NOT NULL,
    "Id_птицефабрики" integer NOT NULL,
    "Вес" integer NOT NULL,
    "Количество яиц ежемесячно" real NOT NULL,
    "Номер_диеты" integer NOT NULL
);


ALTER TABLE public."Курица" OWNER TO postgres;

--
-- Name: Обслуживание клеток; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Обслуживание клеток" (
    "id_клетки" integer NOT NULL,
    "id_работника" integer NOT NULL,
    "Номер_обслуживания" integer NOT NULL,
    "Время_обслуживания" time(4) with time zone NOT NULL,
    "Дата_обслуживания" date
);


ALTER TABLE public."Обслуживание клеток" OWNER TO postgres;

--
-- Name: Порода курицы; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Порода курицы" (
    "Id_породы" integer NOT NULL,
    "Номер_диеты" integer NOT NULL,
    "Производительность" integer NOT NULL,
    "Средний_вес" integer NOT NULL
);


ALTER TABLE public."Порода курицы" OWNER TO postgres;

--
-- Name: Птицефабрика; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Птицефабрика" (
    "Id_Птицефабрики" integer NOT NULL,
    "Работники" integer NOT NULL,
    "Курицы" integer NOT NULL,
    "Цеха" integer NOT NULL
);


ALTER TABLE public."Птицефабрика" OWNER TO postgres;

--
-- Name: Работники; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Работники" (
    "Id_Работника" integer NOT NULL,
    "Паспортные_данные" character(20) NOT NULL,
    "Id_Птицефабрики" integer NOT NULL,
    "Зарплата" integer NOT NULL
);


ALTER TABLE public."Работники" OWNER TO postgres;

--
-- Name: Цех; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Цех" (
    "Номер_цеха" integer NOT NULL,
    "Id_Птицефабрики" integer NOT NULL,
    "Клетки" integer NOT NULL
);


ALTER TABLE public."Цех" OWNER TO postgres;

--
-- Data for Name: Диета; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Диета" ("Номер_диеты", "Содержание_диеты") FROM stdin;
\.
COPY public."Диета" ("Номер_диеты", "Содержание_диеты") FROM '$$PATH$$/2880.dat';

--
-- Data for Name: Клетка; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Клетка" ("Id_Клетки", "Номер_цеха", "Наличие курицы в клетке") FROM stdin;
\.
COPY public."Клетка" ("Id_Клетки", "Номер_цеха", "Наличие курицы в клетке") FROM '$$PATH$$/2879.dat';

--
-- Data for Name: Кормление куриц; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Кормление куриц" ("Номер_Кормления", "Id_Работника", "Id_курицы", "Номер_диеты", "Id_клетки", "Id_породы", "Время_кормления", "Дата_кормления") FROM stdin;
\.
COPY public."Кормление куриц" ("Номер_Кормления", "Id_Работника", "Id_курицы", "Номер_диеты", "Id_клетки", "Id_породы", "Время_кормления", "Дата_кормления") FROM '$$PATH$$/2884.dat';

--
-- Data for Name: Курица; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Курица" ("Id_курица", "id_клетки", "Id_породы", "Id_птицефабрики", "Вес", "Количество яиц ежемесячно", "Номер_диеты") FROM stdin;
\.
COPY public."Курица" ("Id_курица", "id_клетки", "Id_породы", "Id_птицефабрики", "Вес", "Количество яиц ежемесячно", "Номер_диеты") FROM '$$PATH$$/2882.dat';

--
-- Data for Name: Обслуживание клеток; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Обслуживание клеток" ("id_клетки", "id_работника", "Номер_обслуживания", "Время_обслуживания", "Дата_обслуживания") FROM stdin;
\.
COPY public."Обслуживание клеток" ("id_клетки", "id_работника", "Номер_обслуживания", "Время_обслуживания", "Дата_обслуживания") FROM '$$PATH$$/2883.dat';

--
-- Data for Name: Порода курицы; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Порода курицы" ("Id_породы", "Номер_диеты", "Производительность", "Средний_вес") FROM stdin;
\.
COPY public."Порода курицы" ("Id_породы", "Номер_диеты", "Производительность", "Средний_вес") FROM '$$PATH$$/2881.dat';

--
-- Data for Name: Птицефабрика; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Птицефабрика" ("Id_Птицефабрики", "Работники", "Курицы", "Цеха") FROM stdin;
\.
COPY public."Птицефабрика" ("Id_Птицефабрики", "Работники", "Курицы", "Цеха") FROM '$$PATH$$/2876.dat';

--
-- Data for Name: Работники; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Работники" ("Id_Работника", "Паспортные_данные", "Id_Птицефабрики", "Зарплата") FROM stdin;
\.
COPY public."Работники" ("Id_Работника", "Паспортные_данные", "Id_Птицефабрики", "Зарплата") FROM '$$PATH$$/2877.dat';

--
-- Data for Name: Цех; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Цех" ("Номер_цеха", "Id_Птицефабрики", "Клетки") FROM stdin;
\.
COPY public."Цех" ("Номер_цеха", "Id_Птицефабрики", "Клетки") FROM '$$PATH$$/2878.dat';

--
-- Name: Диета Диета_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Диета"
    ADD CONSTRAINT "Диета_pkey" PRIMARY KEY ("Номер_диеты");


--
-- Name: Клетка Клетка_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Клетка"
    ADD CONSTRAINT "Клетка_pkey" PRIMARY KEY ("Id_Клетки");


--
-- Name: Кормление куриц Кормление куриц_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Кормление куриц"
    ADD CONSTRAINT "Кормление куриц_pkey" PRIMARY KEY ("Номер_Кормления");


--
-- Name: Курица Курица_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Курица"
    ADD CONSTRAINT "Курица_pkey" PRIMARY KEY ("Id_курица");


--
-- Name: Обслуживание клеток Обслуживание клеток_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Обслуживание клеток"
    ADD CONSTRAINT "Обслуживание клеток_pkey" PRIMARY KEY ("Номер_обслуживания");


--
-- Name: Порода курицы Порода курицы_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Порода курицы"
    ADD CONSTRAINT "Порода курицы_pkey" PRIMARY KEY ("Id_породы");


--
-- Name: Птицефабрика Птицефабрика_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Птицефабрика"
    ADD CONSTRAINT "Птицефабрика_pkey" PRIMARY KEY ("Id_Птицефабрики");


--
-- Name: Работники Работники_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Работники"
    ADD CONSTRAINT "Работники_pkey" PRIMARY KEY ("Id_Работника");


--
-- Name: Цех Цех_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Цех"
    ADD CONSTRAINT "Цех_pkey" PRIMARY KEY ("Номер_цеха");


--
-- Name: Работники Id_Птицефабрики(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Работники"
    ADD CONSTRAINT "Id_Птицефабрики(FK)" FOREIGN KEY ("Id_Птицефабрики") REFERENCES public."Птицефабрика"("Id_Птицефабрики");


--
-- Name: Цех Id_Птицефабрики(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Цех"
    ADD CONSTRAINT "Id_Птицефабрики(FK)" FOREIGN KEY ("Id_Птицефабрики") REFERENCES public."Птицефабрика"("Id_Птицефабрики");


--
-- Name: Обслуживание клеток Id_клетки(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Обслуживание клеток"
    ADD CONSTRAINT "Id_клетки(FK)" FOREIGN KEY ("id_клетки") REFERENCES public."Клетка"("Id_Клетки");


--
-- Name: Кормление куриц Id_клетки(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Кормление куриц"
    ADD CONSTRAINT "Id_клетки(FK)" FOREIGN KEY ("Id_клетки") REFERENCES public."Клетка"("Id_Клетки");


--
-- Name: Кормление куриц Id_курицы(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Кормление куриц"
    ADD CONSTRAINT "Id_курицы(FK)" FOREIGN KEY ("Id_курицы") REFERENCES public."Курица"("Id_курица");


--
-- Name: Кормление куриц Id_породы; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Кормление куриц"
    ADD CONSTRAINT "Id_породы" FOREIGN KEY ("Id_породы") REFERENCES public."Порода курицы"("Id_породы");


--
-- Name: Обслуживание клеток Id_работника(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Обслуживание клеток"
    ADD CONSTRAINT "Id_работника(FK)" FOREIGN KEY ("id_работника") REFERENCES public."Работники"("Id_Работника");


--
-- Name: Кормление куриц Id_работника(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Кормление куриц"
    ADD CONSTRAINT "Id_работника(FK)" FOREIGN KEY ("Id_Работника") REFERENCES public."Работники"("Id_Работника");


--
-- Name: Курица id_клетки(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Курица"
    ADD CONSTRAINT "id_клетки(FK)" FOREIGN KEY ("id_клетки") REFERENCES public."Клетка"("Id_Клетки");


--
-- Name: Курица id_породы(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Курица"
    ADD CONSTRAINT "id_породы(FK)" FOREIGN KEY ("Id_породы") REFERENCES public."Порода курицы"("Id_породы");


--
-- Name: Курица id_птицефабрики(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Курица"
    ADD CONSTRAINT "id_птицефабрики(FK)" FOREIGN KEY ("Id_птицефабрики") REFERENCES public."Птицефабрика"("Id_Птицефабрики");


--
-- Name: Курица Номер_Диеты; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Курица"
    ADD CONSTRAINT "Номер_Диеты" FOREIGN KEY ("Номер_диеты") REFERENCES public."Диета"("Номер_диеты");


--
-- Name: Порода курицы Номер_диеты(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Порода курицы"
    ADD CONSTRAINT "Номер_диеты(FK)" FOREIGN KEY ("Номер_диеты") REFERENCES public."Диета"("Номер_диеты");


--
-- Name: Кормление куриц Номер_диеты(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Кормление куриц"
    ADD CONSTRAINT "Номер_диеты(FK)" FOREIGN KEY ("Номер_диеты") REFERENCES public."Диета"("Номер_диеты");


--
-- Name: Клетка Номер_цеха(FK); Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Клетка"
    ADD CONSTRAINT "Номер_цеха(FK)" FOREIGN KEY ("Номер_цеха") REFERENCES public."Цех"("Номер_цеха");


--
-- PostgreSQL database dump complete
--

